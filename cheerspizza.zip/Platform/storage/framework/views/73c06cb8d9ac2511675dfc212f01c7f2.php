

<?php $__env->startSection('content'); ?>

<div class="card index">
            <div class="card-header">
                <div class="float-start">

<div class="container">

    <h2>Ajustes de Configuración</h2>
    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-check">
  <input class="form-check-input" type="checkbox" id="showWinners" name="show_winners" <?php echo e($showWinners ? 'checked' : ''); ?>>
  <label class="form-check-label" for="showWinners">
  Mostrar Ganadores
  </label>
</div>
             
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
    </form>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cheerspizza\resources\views/admin\setttings\update.blade.php ENDPATH**/ ?>