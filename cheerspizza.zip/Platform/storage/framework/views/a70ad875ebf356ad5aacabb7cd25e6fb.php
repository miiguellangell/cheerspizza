

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center mt-3">
    <div class="col-md-12">

        <div class="index card ">

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>

            <div class="card-header"><h1>LISTADO DE PARTICIPANTES</h1></div>
            <div class="card-body">
                
            <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-success btn-sm my-2"><i class="fa-solid fa-square-plus"></i> Agregar nuevo participante</a>
                <table class="table table-striped table-bordered">
                    <thead>
                      <tr>
                      <th class="tableh" scope="col">#</th>
                      <th class="tableh" scope="col">Puntos</th>
                        <th class="tableh" scope="col">Nombre de cliente</th>
                        <th class="tableh" scope="col">Teléfono</th>
                        <th class="tableh" scope="col">Correo</th>
                        <th class="tableh" scope="col">Facturas Cargadas</th>
                        <th class="tableh" scope="col">Opciones</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th class="tableb" scope="row"><?php echo e($loop->iteration); ?></th>
                            <td class="tableb"><?php echo e($user->Acumulados); ?></td>
                            <td class="tableb"> <?php echo e($user->name); ?></td>
                            <td class="tableb"> <?php echo e($user->telefono); ?></td>
                            <td class="tableb"><?php echo e($user->email); ?></td>
                            <td class="tableb"><?php echo e($user->FacturasCargadas); ?></td>


                            <td class="tableb">

                            <a href="<?php echo e(route('frontend.profile', $user->id)); ?>" class="btn btn-warning btn-sm"> <i class="fa-solid fa-eye"></i> Ver Perfil</a>
                               
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td colspan="6">
                                <span class="text-danger">
                                    <strong>Usuario no encontrada</strong>
                                </span>
                            </td>
                        <?php endif; ?>
                    </tbody>
                  </table>
            </div>
            <div>
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>    
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cheerspizza\resources\views/admin/users/index.blade.php ENDPATH**/ ?>